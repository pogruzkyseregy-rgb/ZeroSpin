package ru.avrora.zerospin;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.SecureRandom;

/** Общее состояние монетки для приложения и виджета. 0 = AvrorA, 1 = Zero Spin. */
public final class CoinStore {
    public static final int SIDE_A = 0;
    public static final int SIDE_B = 1;
    public static final int HISTORY_SIZE = 12;

    private static final String PREFS = "coin";
    private static final SecureRandom RNG = new SecureRandom();

    private CoinStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Честный бросок: криптостойкий генератор, 50/50. */
    public static int toss() {
        return RNG.nextBoolean() ? SIDE_A : SIDE_B;
    }

    public static int last(Context c) { return prefs(c).getInt("last", SIDE_A); }
    public static int countA(Context c) { return prefs(c).getInt("a", 0); }
    public static int countB(Context c) { return prefs(c).getInt("b", 0); }
    public static boolean hasFlipped(Context c) { return prefs(c).getBoolean("flipped", false); }
    public static String history(Context c) { return prefs(c).getString("hist", ""); }

    /** Записывает результат и сообщает виджетам. */
    public static synchronized void record(Context c, int side) {
        SharedPreferences p = prefs(c);
        String h = (side == SIDE_A ? "a" : "b") + p.getString("hist", "");
        if (h.length() > HISTORY_SIZE) h = h.substring(0, HISTORY_SIZE);
        p.edit()
                .putInt("last", side)
                .putInt(side == SIDE_A ? "a" : "b", p.getInt(side == SIDE_A ? "a" : "b", 0) + 1)
                .putString("hist", h)
                .putBoolean("flipped", true)
                .apply();
    }

    public static void reset(Context c) {
        int last = last(c);
        prefs(c).edit().clear().putInt("last", last).apply();
    }
}

package ru.avrora.zerospin;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.List;

/** Виджет 2x2: нажатие на монету подбрасывает её прямо на рабочем столе. */
public class CoinWidget extends AppWidgetProvider {

    static final String ACTION_FLIP = "ru.avrora.zerospin.FLIP";
    private static final long FRAME_MS = 45;
    private static volatile boolean animating = false;

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            mgr.updateAppWidget(id, buildViews(ctx, CoinStore.last(ctx)));
        }
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (!ACTION_FLIP.equals(intent.getAction()) || animating) return;
        animating = true;

        final Context app = ctx.getApplicationContext();
        final PendingResult pending = goAsync();
        final AppWidgetManager mgr = AppWidgetManager.getInstance(app);
        final int[] ids = mgr.getAppWidgetIds(new ComponentName(app, CoinWidget.class));

        final int from = CoinStore.last(app);
        final int result = CoinStore.toss();
        final List<Integer> frames = buildFrames(from, result);
        final Handler h = new Handler(Looper.getMainLooper());

        // Пока крутится — подпись прячем
        RemoteViews start = new RemoteViews(app.getPackageName(), R.layout.widget_coin);
        start.setTextViewText(R.id.w_label, " ");
        for (int id : ids) mgr.partiallyUpdateAppWidget(id, start);

        for (int i = 0; i < frames.size(); i++) {
            final int res = frames.get(i);
            final boolean lastFrame = i == frames.size() - 1;
            h.postDelayed(() -> {
                if (lastFrame) {
                    CoinStore.record(app, result);
                    for (int id : ids) mgr.updateAppWidget(id, buildViews(app, result));
                    animating = false;
                    pending.finish();
                } else {
                    RemoteViews rv = new RemoteViews(app.getPackageName(), R.layout.widget_coin);
                    rv.setImageViewResource(R.id.w_coin, res);
                    for (int id : ids) mgr.partiallyUpdateAppWidget(id, rv);
                }
            }, FRAME_MS * i);
        }
    }

    /** Кадры вращения: каждые пол-оборота = 6 кадров (сжатие, ребро, раскрытие). */
    private static List<Integer> buildFrames(int from, int result) {
        int halfTurns = 6 + (from == result ? 0 : 1); // чётность определяет итоговую сторону
        List<Integer> f = new ArrayList<>();
        int side = from;
        for (int t = 0; t < halfTurns; t++) {
            int next = 1 - side;
            f.add(side == CoinStore.SIDE_A ? R.drawable.w_a1 : R.drawable.w_b1);
            f.add(side == CoinStore.SIDE_A ? R.drawable.w_a2 : R.drawable.w_b2);
            f.add(R.drawable.w_edge);
            f.add(next == CoinStore.SIDE_A ? R.drawable.w_a2 : R.drawable.w_b2);
            f.add(next == CoinStore.SIDE_A ? R.drawable.w_a1 : R.drawable.w_b1);
            f.add(next == CoinStore.SIDE_A ? R.drawable.w_a0 : R.drawable.w_b0);
            side = next;
        }
        return f;
    }

    static RemoteViews buildViews(Context ctx, int side) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_coin);
        rv.setImageViewResource(R.id.w_coin, side == CoinStore.SIDE_A ? R.drawable.w_a0 : R.drawable.w_b0);
        rv.setTextViewText(R.id.w_label, ctx.getString(side == CoinStore.SIDE_A ? R.string.side_a : R.string.side_b));

        Intent flip = new Intent(ctx, CoinWidget.class).setAction(ACTION_FLIP);
        PendingIntent flipPi = PendingIntent.getBroadcast(ctx, 0, flip,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.w_coin, flipPi);

        Intent open = new Intent(ctx, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(ctx, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.w_label, openPi);
        return rv;
    }

    /** Обновить все виджеты (вызывается из приложения после броска). */
    static void refreshAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, CoinWidget.class));
        int side = CoinStore.last(ctx);
        for (int id : ids) mgr.updateAppWidget(id, buildViews(ctx, side));
    }
}

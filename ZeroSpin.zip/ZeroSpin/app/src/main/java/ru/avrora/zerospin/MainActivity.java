package ru.avrora.zerospin;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowInsets;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private ImageView coin;
    private View glow, shadow;
    private TextView result, countA, countB, pctA, pctB, total;
    private LinearLayout history;

    private int shownSide;
    private boolean flipping = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        setContentView(R.layout.activity_main);

        coin = findViewById(R.id.coin);
        glow = findViewById(R.id.glow);
        shadow = findViewById(R.id.shadow);
        result = findViewById(R.id.result);
        countA = findViewById(R.id.count_a);
        countB = findViewById(R.id.count_b);
        pctA = findViewById(R.id.pct_a);
        pctB = findViewById(R.id.pct_b);
        total = findViewById(R.id.total);
        history = findViewById(R.id.history);

        float density = getResources().getDisplayMetrics().density;
        coin.setCameraDistance(9000 * density);

        View content = findViewById(R.id.content);
        content.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars());
                top = i.top; bottom = i.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), bottom);
            return insets;
        });

        coin.setOnClickListener(v -> flip());
        findViewById(R.id.stats).setOnLongClickListener(v -> {
            if (flipping) return true;
            CoinStore.reset(this);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show();
            refreshUi(false);
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!flipping) refreshUi(false); // мог подбросить виджет, пока приложение было свёрнуто
    }

    private void flip() {
        if (flipping) return;
        flipping = true;
        coin.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);

        final int from = shownSide;
        final int res = CoinStore.toss();
        int halfTurns = 10 + 2 * (int) (Math.random() * 3);  // 10, 12 или 14
        if (from != res) halfTurns += 1;                    // нечётное число — сторона сменится
        final float totalDeg = halfTurns * 180f;
        final float lift = coin.getHeight() * 0.95f;

        result.animate().alpha(0f).setDuration(120).start();
        glow.animate().alpha(0f).setDuration(120).start();

        ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(1500 + halfTurns * 20L);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            // вращение быстрее в начале, замедляется к приземлению
            float spin = 1f - (1f - t) * (1f - t);
            float deg = totalDeg * spin;
            int k = Math.round(deg / 180f);          // сколько раз перевернулась
            int side = (k % 2 == 0) ? from : 1 - from;
            setFace(side);
            coin.setRotationY(deg - k * 180f);         // всегда -90..90, картинка не зеркалится

            // полёт по параболе
            float h = 4f * t * (1f - t);
            coin.setTranslationY(-lift * h);
            float s = 1f + 0.25f * h;
            coin.setScaleX(s);
            coin.setScaleY(s);
            shadow.setScaleX(1f - 0.55f * h);
            shadow.setAlpha(1f - 0.7f * h);
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                coin.setRotationY(0f);
                coin.setTranslationY(0f);
                setFace(res);
                land();
                CoinStore.record(MainActivity.this, res);
                CoinWidget.refreshAll(MainActivity.this);
                refreshUi(true);
                flipping = false;
            }
        });
        anim.start();
    }

    /** Приземление: короткий отскок, вибрация и вспышка. */
    private void land() {
        vibrate();
        coin.setScaleX(1.08f);
        coin.setScaleY(0.94f);
        coin.animate().scaleX(1f).scaleY(1f).setDuration(220).start();
        glow.setAlpha(1f);
        glow.animate().alpha(0.35f).setDuration(900).start();
    }

    private void vibrate() {
        Vibrator v = getSystemService(Vibrator.class);
        if (v == null || !v.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 29) {
            v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK));
        } else {
            v.vibrate(VibrationEffect.createOneShot(30, 200));
        }
    }

    private void setFace(int side) {
        if (side == shownSide && coin.getTag() != null) return;
        shownSide = side;
        coin.setTag(side);
        coin.setImageResource(side == CoinStore.SIDE_A ? R.drawable.coin_a : R.drawable.coin_b);
    }

    private void refreshUi(boolean justFlipped) {
        if (!flipping || justFlipped) setFace(CoinStore.last(this));

        int a = CoinStore.countA(this), b = CoinStore.countB(this), n = a + b;
        countA.setText(String.valueOf(a));
        countB.setText(String.valueOf(b));
        if (n > 0) {
            pctA.setText(getString(R.string.side_a) + "  " + Math.round(a * 100f / n) + "%");
            pctB.setText(getString(R.string.side_b) + "  " + Math.round(b * 100f / n) + "%");
            total.setText(getString(R.string.total, n));
        } else {
            pctA.setText(R.string.side_a);
            pctB.setText(R.string.side_b);
            total.setText(R.string.reset_hint);
        }

        if (CoinStore.hasFlipped(this)) {
            result.setText(shownSide == CoinStore.SIDE_A ? R.string.side_a : R.string.side_b);
            glow.setAlpha(Math.max(glow.getAlpha(), 0.35f));
        } else {
            result.setText(R.string.hint);
        }
        result.animate().alpha(1f).setDuration(250).start();

        // последние броски: светлая точка = AvrorA, контур = Zero Spin
        history.removeAllViews();
        float d = getResources().getDisplayMetrics().density;
        for (char c : CoinStore.history(this).toCharArray()) {
            View dot = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (10 * d), (int) (10 * d));
            lp.setMargins((int) (4 * d), 0, (int) (4 * d), 0);
            dot.setLayoutParams(lp);
            dot.setBackgroundResource(c == 'a' ? R.drawable.dot_a : R.drawable.dot_b);
            history.addView(dot);
        }
        if (history.getChildCount() > 0) history.getChildAt(0).setAlpha(1f);
        for (int i = 1; i < history.getChildCount(); i++) {
            history.getChildAt(i).setAlpha(1f - i * 0.06f);
        }
    }
}

# Zero Spin — монетка Авроры

Подбрасывание монетки: AvrorA / Zero Spin. Есть виджет 2x2 — монета крутится прямо на рабочем столе.

## Сборка
Залей папку в репозиторий GitHub → Actions → Build APK → артефакт `ZeroSpin-apk`.

Подпись: `app/zerospin.jks` (пароль в `app/build.gradle`). Не теряй этот файл — без него обновления не встанут поверх старой версии.

## Где что менять
- Картинки сторон: `app/src/main/res/drawable-nodpi/coin_a.png`, `coin_b.png`
- Кадры виджета: `w_a0..w_a2`, `w_b0..w_b2`, `w_edge`
- Фон: `bg_space.jpg`
- Тексты: `res/values/strings.xml`
